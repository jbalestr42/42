/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirect.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/24 22:12:04 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 20:17:28 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	ast_exec_double_redirect(t_ast *node, int oflags, t_env *env)
{
	int		fds[2];
	char	*file_name_in;
	char	*file_name_out;

	if (!ast_is_node_type(node->right->right, WORD))
		ambiguous_redirect_error(node->right->right, 0);
	else
	{
		file_name_in = ast_node_token_value(node->right->left);
		file_name_out = ast_node_token_value(node->right->right);
		fds[0] = open_file(file_name_in, O_RDONLY, 0);
		if (is_valid_fd(fds[0]))
		{
			fds[1] = open_file(file_name_out, oflags, CREATE_PERMISSIONS);
			if (is_valid_fd(fds[1]))
				redirect_one(node->left, fds, env);
		}
	}
}

static void	ast_exec_redirect_pipe(t_ast *node, t_env *env)
{
	int		fd_in;
	char	*file_name;

	file_name = ast_node_token_value(node->right->left);
	fd_in = open_file(file_name, O_RDONLY, 0);
	if (is_valid_fd(fd_in))
	{
		ast_swap_tokens(node->left, node->right->left);
		ast_exec_piped(node->right, env, fd_in);
	}
}

void		ast_exec_r_redirect(t_ast *node, t_env *env, int oflags)
{
	int		fds[2] = {-1, -1};
	char	*file_name;

	if (ast_is_node_type(node->right, WORD))
	{
		file_name = ast_node_token_value(node->right);
		fds[1] = open_file(file_name, oflags, CREATE_PERMISSIONS);
		if (is_valid_fd(fds[1]))
			redirect_one(node->left, fds, env);
	}
	else
		ambiguous_redirect_error(node->right, 0);
}

void		ast_exec_l_redirect(t_ast *node, t_env *env)
{
	int		fds[2] = {-1, -1};
	char	*file_name;

	if (ast_is_node_type(node->right, WORD))
	{
		file_name = ast_node_token_value(node->right);
		fds[0] = open_file(file_name, O_RDONLY, 0);
		if (is_valid_fd(fds[0]))
			redirect_one(node->left, fds, env);
	}
	else if (ast_is_node_type(node->right, OP_PIPE))
		ast_exec_redirect_pipe(node, env);
	else if (ast_is_node_type(node->right, OP_REDIRECT_RIGHT))
		ast_exec_double_redirect(node, TRUNC_OFLAGS, env);
	else if (ast_is_node_type(node->right, OP_REDIRECT_RIGHT2))
		ast_exec_double_redirect(node, APPEND_OFLAGS, env);
	else
		ambiguous_redirect_error(node->right, 0);
}
