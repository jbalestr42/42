/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/23 20:12:16 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/25 00:17:52 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*
** OP_SEMI_COLON		=		;
** OP_PIPE				=		|
** OP_REDIRECT_LEFT		=		<
** OP_REDIRECT_RIGHT	=		>
** OP_REDIRECT_LEFT2	=		<<
** OP_REDIRECT_RIGHT2	=		>>
** WORD					=		[\d\w_-./]+
**
** E					::=		[OP_SEMI_COLON]? exp
**
** exp					::=		instruction [OP_SEMI_COLON | OP_SEMI_COLON exp]?
**
** instruction			::=		cmd [operator instruction]?
**
** operator				::=		OP_PIPE | OP_REDIRECT_LEFT | OP_REDIRECT_RIGHT
**								| OP_REDIRECT_LEFT2 | OP_REDIRECT_RIGHT2
**
** cmd					::=		WORD [arg]*
**
** arg					::=		WORD
*/

static int	parse_arg(t_list **tokens, t_ast *node)
{
	t_token	*token;

	token = get_token(tokens);
	if (token && token->type == WORD)
	{
		ast_add_token_to_node(node, token);
		next_token(tokens);
		return (1);
	}
	return (0);
}

static int	parse_cmd(t_list **tokens, t_ast **node)
{
	t_token	*token;

	token = get_token(tokens);
	if (token && token->type == WORD)
	{
		*node = ast_new(token);
		next_token(tokens);
		while (parse_arg(tokens, *node))
			;
		return (1);
	}
	return (0);
}

static int	is_instruction_op_token(t_token *token)
{
	if (token)
	{
		return (token->type == OP_PIPE
				|| token->type == OP_REDIRECT_LEFT
				|| token->type == OP_REDIRECT_RIGHT
				|| token->type == OP_REDIRECT_LEFT2
				|| token->type == OP_REDIRECT_RIGHT2);
	}
	return (0);
}

int			parse_instruction(t_list **tokens, t_ast **node)
{
	t_token	*token;
	t_ast	*sep_node;

	sep_node = ast_new(0);
	if (parse_cmd(tokens, &sep_node->left))
	{
		token = get_token(tokens);
		if (is_instruction_op_token(token))
		{
			ast_add_token_to_node(sep_node, token);
			next_token(tokens);
			if (!parse_instruction(tokens, &sep_node->right))
			{
				ast_free(sep_node);
				return (0);
			}
			*node = sep_node;
			return (1);
		}
		*node = sep_node->left;
		free(sep_node);
		return (1);
	}
	free(sep_node);
	return (0);
}

int			parse_exp(t_list **tokens, t_ast **node)
{
	t_token	*token;
	t_ast	*semi_col_node;

	semi_col_node = ast_new(0);
	if (parse_instruction(tokens, &semi_col_node->left))
	{
		token = get_token(tokens);
		if (token && token->type == OP_SEMI_COLON)
		{
			ast_add_token_to_node(semi_col_node, token);
			next_token(tokens);
			if (parse_exp(tokens, &semi_col_node->right))
			{
				*node = semi_col_node;
				return (1);
			}
		}
		*node = semi_col_node->left;
		free(semi_col_node);
		return (1);
	}
	free(semi_col_node);
	return (0);
}
