/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipe2.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/24 19:01:46 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 19:43:55 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	exec_one_piped(t_ast *node, t_env *env, int fds[4])
{
	dupif(fds[2], STDIN);
	dup2(fds[1], STDOUT);
	close_all(fds);
	close_all(fds + 2);
	ast_exec_cmd(node, env, 1);
	exit(1);
}

void	closeif(int fd)
{
	if (is_valid_fd(fd))
		close(fd);
}

void	close_all(int fds[2])
{
	closeif(fds[0]);
	closeif(fds[1]);
}

void	dupif(int fd1, int fd2)
{
	if (is_valid_fd(fd1))
		dup2(fd1, fd2);
}
