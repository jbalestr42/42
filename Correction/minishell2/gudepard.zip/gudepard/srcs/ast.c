/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ast.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/23 18:06:36 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 17:00:41 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

t_ast		*ast_new(t_token *token)
{
	t_ast	*ast;

	ast = (t_ast *)malloc(sizeof(t_ast));
	if (ast)
	{
		ast->tokens = (token ? ft_lstnew(token, sizeof(t_token)) : 0);
		ast->left = 0;
		ast->right = 0;
	}
	return (ast);
}

void		ast_free(t_ast *node)
{
	if (node)
	{
		ast_free(node->left);
		ast_free(node->right);
		ft_lstdel(&node->tokens, (t_deleter)free);
		free(node);
	}
}

void		ast_add_token_to_node(t_ast *node, t_token *token)
{
	t_list	*token_elem;

	token_elem = ft_lstnew(token, sizeof(t_token));
	ft_lstappend(&node->tokens, token_elem);
}

int			ast_is_node_type(t_ast *node, t_token_type type)
{
	t_token	*token;

	token = (t_token *)node->tokens->content;
	return (token->type == type);
}

t_ast		*next_node_of_type(t_ast *node, t_token_type type)
{
	t_ast	*found;

	if (node)
	{
		if (ast_is_node_type(node, type))
			return (node);
		found = next_node_of_type(node->left, type);
		if (found)
			return (found);
		found = next_node_of_type(node->right, type);
		if (found)
			return (found);
	}
	return (0);
}
