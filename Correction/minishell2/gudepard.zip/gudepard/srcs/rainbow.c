/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rainbow.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/27 03:55:14 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/27 04:01:14 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	show_rainbow(void)
{
	int	i;

	i = 0;
	while (i < 256)
	{
		ft_setfgcolor(i);
		ft_putnbr(i++);
		ft_putchar('\t');
		ft_resetcolor();
	}
	ft_putchar('\n');
}

void	b_rainbow(t_env *env, size_t argc, char **args)
{
	(void)env;
	(void)args;
	if (argc == 1)
		show_rainbow();
	else
		builtin_error(RAINBOW_COMMAND, ERR_TOO_MANY_ARGS, 0);
}
