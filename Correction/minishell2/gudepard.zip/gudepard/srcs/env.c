/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/24 18:06:24 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 18:37:35 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

extern char			**environ;

void				init_env_vars(t_env *env)
{
	size_t			i;
	char			*var_name;
	char			*var_value;
	t_map_entry		entry;

	i = 0;
	while (environ[i])
	{
		var_value = ft_strchr(environ[i], '=') + 1;
		var_name = ft_strsub(environ[i], 0, var_value - environ[i] - 1);
		entry.key = var_name;
		entry.value = ft_strdup(var_value);
		ft_map_insert(env->vars, entry, ft_djb2);
		++i;
	}
}

static t_env		*new_env(void)
{
	t_env			*env;

	env = (t_env *)malloc(sizeof(t_env));
	if (env)
	{
		env->running = 0;
		env->heredoc = 0;
		ft_bzero(env->vars, sizeof(env->vars));
	}
	return (env);
}

t_env				*get_env(void)
{
	static t_env	*env = 0;

	if (!env)
		env = new_env();
	return (env);
}

t_env				*dup_env(t_env *env)
{
	t_env			*copy;

	copy = new_env();
	ft_map_foreach(env->vars, map_copy_one, &copy->vars);
	return (copy);
}

void				free_env(t_env *env)
{
	ft_map_delete(env->vars, env_map_del);
	free(env);
}
