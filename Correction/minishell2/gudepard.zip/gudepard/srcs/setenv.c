/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   setenv.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 09:27:07 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/24 19:33:26 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	b_setenv(t_env *env, size_t argc, char **args)
{
	if (argc == 3)
	{
		if (ft_strcmp(args[1], VAR_PWD))
			env_set(env, args[1], args[2]);
	}
	else if (argc > 3)
		builtin_error(SETENV_COMMAND, ERR_TOO_MANY_ARGS, 0);
	else
		builtin_error(SETENV_COMMAND, ERR_TOO_FEW_ARGS, 0);
}

void	b_unsetenv(t_env *env, size_t argc, char **args)
{
	char	*value;

	if (argc == 2)
	{
		if (ft_strcmp(args[1], VAR_PWD))
		{
			value = env_get(env, args[1]);
			if (value)
				env_remove(env, args[1]);
			else
				builtin_error(UNSETENV_COMMAND, ERR_VAR_NON_EXISTING, args[1]);
		}
	}
	else if (argc > 2)
		builtin_error(UNSETENV_COMMAND, ERR_TOO_MANY_ARGS, 0);
	else
		builtin_error(UNSETENV_COMMAND, ERR_TOO_FEW_ARGS, 0);
}
