/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   str_replace.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/29 16:25:27 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/29 16:38:32 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	*str_replace(const char *str, const char *old, const char *new)
{
	char	*rep;
	char	*old_id;
	size_t	old_len;
	size_t	str_len;
	size_t	new_len;

	rep = 0;
	old_id = ft_strstr(str, old);
	if (old_id)
	{
		str_len = ft_strlen(str);
		old_len = ft_strlen(old);
		new_len = ft_strlen(new);
		rep = (char *)malloc(sizeof(char) * (str_len - old_len + new_len + 1));
		if (rep)
		{
			ft_strncpy(rep, str, old_id - str);
			ft_strncpy(rep + (old_id - str), new, new_len);
			ft_strcpy(rep + (old_id - str) + new_len, old_id + old_len);
		}
	}
	return (rep);
}
