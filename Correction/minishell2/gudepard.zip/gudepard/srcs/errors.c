/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errors.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/23 15:19:26 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/25 18:17:03 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	shell_error(const char *what, const char *info)
{
	write(STDERR, SHELL_ERROR_PREFIX, sizeof(SHELL_ERROR_PREFIX));
	write(STDERR, ": ", 2);
	ft_putstr_fd(what, STDERR);
	if (info)
	{
		write(STDERR, ": ", 2);
		ft_putstr_fd(info, STDERR);
	}
	ft_putchar_fd('\n', STDERR);
}

void	builtin_error(const char *command, const char *type, const char *info)
{
	ft_putstr_fd(command, STDERR);
	write(STDERR, ": ", 2);
	ft_putstr_fd(type, STDERR);
	if (info)
	{
		write(STDERR, ": ", 2);
		ft_putstr_fd(info, STDERR);
	}
	ft_putchar_fd('\n', STDERR);
}
