/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   open.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/24 23:55:25 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 21:02:11 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int		open_file(const char *name, int oflags, mode_t mode)
{
	int	fd;

	fd = open(name, oflags, mode);
	if (fd == -1)
	{
		if ((oflags & O_CREAT) != O_CREAT)
		{
			if (access(name, F_OK) == -1)
				shell_error(ERR_FILE_NON_EXISTING, name);
			else if ((oflags & O_RDONLY) == O_RDONLY
					&& access(name, R_OK) == -1)
				shell_error(ERR_DENIED, name);
		}
		else
			shell_error(ERR_DENIED, name);
	}
	return (fd);
}

int		is_valid_fd(int fd)
{
	return (fd != -1);
}
