/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tokens.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/24 19:10:20 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/24 19:16:22 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

t_token		*get_token(t_list **tokens)
{
	t_token	*token;

	token = 0;
	if (*tokens)
		token = (t_token *)(*tokens)->content;
	return (token);
}

void		next_token(t_list **tokens)
{
	*tokens = (*tokens)->next;
}

void		free_token(void *data, size_t size)
{
	t_token		*token;

	UNUSED(size);
	token = (t_token *)data;
	free(token->value);
	free(token);
}

char		**tokens_as_char_array(t_list *tokens)
{
	char	**args;
	size_t	i;

	args = (char **)malloc(sizeof(char *) * (ft_lstsize(tokens) + 1));
	i = 0;
	while (tokens)
	{
		args[i++] = ((t_token *)(tokens->content))->value;
		tokens = tokens->next;
	}
	args[i] = 0;
	return (args);
}
