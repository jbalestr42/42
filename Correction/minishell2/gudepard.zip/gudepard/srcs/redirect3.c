/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirect3.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/26 16:28:03 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 19:33:38 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void		ambiguous_redirect_error(t_ast *node, int do_exit)
{
	t_token	*token;

	token = (t_token *)node->tokens->content;
	shell_error(ERR_AMBIGUOUS_REDIRECT, token->value);
	if (do_exit)
		exit(1);
}

void		redirect_one(t_ast *cmd_node, int fds[2], t_env *env)
{
	pid_t	pid;

	pid = fork();
	if (pid != -1)
	{
		if (pid == 0)
		{
			dupif(fds[0], STDIN);
			dupif(fds[1], STDOUT);
			close_all(fds);
			ast_exec_cmd(cmd_node, env, 1);
			exit(1);
		}
		else
		{
			close_all(fds);
			wait(0);
		}
	}
	else
		shell_error(ERR_FORK_FAILED, 0);
}
