/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt_color.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 16:45:50 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/26 16:46:22 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	process_color(const char **fmt, t_list **str)
{
	int		n;
	char	*n_str;

	n = 0;
	while (**fmt && **fmt != '}')
	{
		if (!ft_isdigit(**fmt))
			return ;
		n = n * 10 + **fmt - '0';
		++(*fmt);
	}
	if (!**fmt)
		return ;
	++(*fmt);
	n %= 256;
	n_str = ft_itoa(n);
	ft_lstadd(str, ft_lstnew("\033[38;5;", 8));
	ft_lstadd(str, ft_lstnew(n_str, ft_strlen(n_str) + 1));
	ft_lstadd(str, ft_lstnew("m", 2));
	free(n_str);
}
