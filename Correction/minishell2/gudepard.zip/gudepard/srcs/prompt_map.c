/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt_map.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 21:46:56 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/21 21:51:39 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void			add_to_map(t_map *map, char c, t_prompt_proc proc)
{
	t_map_entry		entry;

	entry.key = &c;
	entry.value = proc;
	ft_map_insert(*map, entry, char_hash);
}

t_map				*prompt_format_map(void)
{
	static t_map	*format_map = 0;

	if (!format_map)
	{
		format_map = (t_map *)ft_memalloc(sizeof(t_map));
		add_to_map(format_map, 'c', prompt_format_c);
		add_to_map(format_map, 'n', prompt_format_n);
	}
	return (format_map);
}
