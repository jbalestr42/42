/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/22 15:06:54 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/24 19:16:12 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*
** OP_SEMI_COLON		=		;
** OP_PIPE				=		|
** OP_REDIRECT_LEFT		=		<
** OP_REDIRECT_RIGHT	=		>
** OP_REDIRECT_LEFT2	=		<<
** OP_REDIRECT_RIGHT2	=		>>
** WORD					=		[\d\w_-./]+
**
** E					::=		[OP_SEMI_COLON]? exp
**
** exp					::=		instruction [OP_SEMI_COLON | OP_SEMI_COLON exp]?
**
** instruction			::=		cmd [operator instruction]?
**
** operator				::=		OP_PIPE | OP_REDIRECT_LEFT | OP_REDIRECT_RIGHT
**								| OP_REDIRECT_LEFT2 | OP_REDIRECT_RIGHT2
**
** cmd					::=		WORD [arg]*
**
** arg					::=		WORD
*/

static int	parse_E(t_list **tokens, t_ast *node)
{
	t_token	*current;

	current = get_token(tokens);
	if (current->type == OP_SEMI_COLON)
		next_token(tokens);
	return (parse_exp(tokens, &node->left));
}

t_ast		*parse_tokens(t_list *tokens)
{
	t_ast	*root;
	t_token	*last_token;
	char	*err;

	if (!tokens)
		return (0);
	root = ast_new(0);
	if (parse_E(&tokens, root) && !tokens)
		return (root);
	ast_free(root);
	err = ERR_PARSE_END;
	if (tokens)
	{
		last_token = (t_token *)tokens->content;
		err = last_token->value;
	}
	shell_error(ERR_PARSE, err);
	return (0);
}
