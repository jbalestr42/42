/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute_line.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/23 17:52:14 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 20:12:30 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void		ast_exec_cmd(t_ast *node, t_env *env, int detached)
{
	char	**args;
	t_cmd	cmd;

	args = tokens_as_char_array(node->tokens);
	if (args && *args)
	{
		cmd = get_builtin_cmd(*args);
		if (cmd)
			cmd(env, char_array_len(args), args);
		else
			exec_bin(env, env, args, detached);
	}
	free(args);
}

static void	walk_tree(t_ast *ast, t_env *env)
{
	if (ast)
	{
		if (ast_is_node_type(ast, OP_PIPE))
			ast_exec_piped(ast, env, -1);
		else if (ast_is_node_type(ast, OP_SEMI_COLON))
		{
			walk_tree(ast->left, env);
			walk_tree(ast->right, env);
		}
		else if (ast_is_node_type(ast, OP_REDIRECT_RIGHT))
			ast_exec_r_redirect(ast, env, TRUNC_OFLAGS);
		else if (ast_is_node_type(ast, OP_REDIRECT_RIGHT2))
			ast_exec_r_redirect(ast, env, APPEND_OFLAGS);
		else if (ast_is_node_type(ast, OP_REDIRECT_LEFT))
			ast_exec_l_redirect(ast, env);
		else if (ast_is_node_type(ast, OP_REDIRECT_LEFT2))
			ast_exec_heredoc(ast, env);
		else if (ast_is_node_type(ast, WORD))
			ast_exec_cmd(ast, env, 0);
	}
}

void		execute_line(char *line, t_env *env)
{
	t_list	*tokens;
	t_ast	*syntax_tree;

	tokens = tokenize(line);
	if (tokens)
	{
		syntax_tree = parse_tokens(tokens);
		if (syntax_tree)
		{
			walk_tree(syntax_tree->left, env);
			ast_free(syntax_tree);
			ft_lstdel(&tokens, free_token);
		}
	}
}
