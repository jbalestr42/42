/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirect2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/25 15:43:07 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 20:38:49 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	redirect_heredoc(t_ast *node, t_list *input, t_env *env, int fd_out)
{
	int		fds[3];
	pid_t	pid;

	fds[2] = fd_out;
	if (!pipe(fds))
	{
		pid = fork();
		if (pid != -1)
		{
			if (pid == 0)
				dump_heredoc(node, input, fds, env);
			else
			{
				close_all(fds);
				closeif(fd_out);
				wait(0);
			}
		}
		else
			shell_error(ERR_FORK_FAILED, 0);
	}
	else
		shell_error(ERR_PIPE_FAILED, 0);
}

static void	piped_heredoc(t_ast *node, t_list *input, t_env *env)
{
	int		fds[3];
	pid_t	pid;

	if (!pipe(fds))
	{
		pid = fork();
		if (pid != -1)
		{
			if (pid == 0)
				dump_heredoc_piped(node, input, fds, env);
			else
			{
				close_all(fds);
				wait(0);
			}
		}
		else
			shell_error(ERR_FORK_FAILED, 0);
	}
	else
		shell_error(ERR_PIPE_FAILED, 0);
}

static void	ast_exec_heredoc_r_redirect(t_ast *node, int oflags, t_env *env)
{
	t_list	*input;
	char	*file_name;
	char	*end_token;
	int		fd_out;

	if (ast_is_node_type(node->right->right, WORD))
	{
		file_name = ast_node_token_value(node->right->right);
		end_token = ast_node_token_value(node->right->left);
		fd_out = open_file(file_name, oflags, CREATE_PERMISSIONS);
		input = read_heredoc(end_token, env);
		redirect_heredoc(node->left, input, env, fd_out);
		ft_lstdel(&input, (t_deleter)free);
	}
	else
		ambiguous_redirect_error(node->right->right, 0);
}

static void	ast_exec_heredoc_pipe(t_ast *node, t_env *env)
{
	t_list	*input;
	char	*end_token;

	end_token = ast_node_token_value(node->right->left);
	input = read_heredoc(end_token, env);
	ast_swap_tokens(node->left, node->right->left);
	piped_heredoc(node->right, input, env);
	ft_lstdel(&input, (t_deleter)free);
}

void		ast_exec_heredoc(t_ast *node, t_env *env)
{
	t_list	*input;
	char	*end_token;

	if (ast_is_node_type(node->right, WORD))
	{
		end_token = ast_node_token_value(node->right);
		input = read_heredoc(end_token, env);
		redirect_heredoc(node->left, input, env, -1);
		ft_lstdel(&input, (t_deleter)free);
	}
	else if (ast_is_node_type(node->right, OP_PIPE))
		ast_exec_heredoc_pipe(node, env);
	else if (ast_is_node_type(node->right, OP_REDIRECT_RIGHT))
		ast_exec_heredoc_r_redirect(node, TRUNC_OFLAGS, env);
	else if (ast_is_node_type(node->right, OP_REDIRECT_RIGHT2))
		ast_exec_heredoc_r_redirect(node, APPEND_OFLAGS, env);
	else
		ambiguous_redirect_error(node->right, 0);
}
