/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_bin.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/24 19:53:38 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/21 19:25:38 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int			is_file(const char *full_path)
{
	t_stat	file_stat;

	if (!stat(full_path, &file_stat))
		return (S_ISREG(file_stat.st_mode));
	return (0);
}

int			is_dir(const char *full_path)
{
	t_stat	file_stat;

	if (!stat(full_path, &file_stat))
		return (S_ISDIR(file_stat.st_mode));
	return (0);
}

char		*find_bin(t_env *env, const char *name)
{
	char	**paths;
	char	*full_path;
	char	*bin;
	size_t	i;

	bin = 0;
	paths = ft_strsplit(env_get(env, VAR_PATH), ':');
	if (paths)
	{
		i = 0;
		while (paths[i])
		{
			full_path = path_join(paths[i], name);
			if (!access(full_path, F_OK) && is_file(full_path))
			{
				bin = full_path;
				break ;
			}
			free(full_path);
			++i;
		}
		char_array_free(paths);
	}
	return (bin);
}

char		*find_bin2(t_env *env, const char *name)
{
	char	*full_path;
	char	*folder;
	char	*bin;
	char	*pwd;

	bin = 0;
	if (*name == '/')
		full_path = ft_strdup(name);
	else
	{
		pwd = env_get(env, VAR_PWD);
		pwd = (pwd ? ft_strdup(pwd) : getcwd(0, 0));
		full_path = path_join(pwd, name);
		free(pwd);
	}
	folder = path_join(full_path, "..");
	if (!access(full_path, F_OK) || !ft_strcmp(name, "/"))
		bin = full_path;
	else
		free(full_path);
	free(folder);
	return (bin);
}
