/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   char_array.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/23 10:49:27 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/21 22:11:12 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

size_t			char_array_map(char **array, size_t (*functor)(const char *))
{
	size_t	total;
	size_t	i;

	total = 0;
	if (array)
	{
		i = 0;
		while (array[i])
			total += functor(array[i++]);
	}
	return (total);
}

static size_t	one(const char *str)
{
	(void)str;
	return (1);
}

size_t			char_array_len(char **array)
{
	if (array)
		return (char_array_map(array, one));
	return (0);
}

void			char_array_free(char **array)
{
	char_array_map(array, (size_t (*)(const char *))free);
	free(array);
}

char			**char_array_from_list(t_list *list)
{
	char	**array;
	size_t	i;

	array = (char **)malloc(sizeof(char *) * (ft_lstsize(list) + 1));
	if (array)
	{
		i = 0;
		while (list)
		{
			array[i++] = ft_strdup((char *)list->content);
			list = list->next;
		}
		array[i] = 0;
	}
	return (array);
}
